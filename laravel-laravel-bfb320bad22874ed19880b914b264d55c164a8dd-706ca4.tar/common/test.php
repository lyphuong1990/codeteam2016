<?php 
/**
* 
*/
namespace Common;

use Carbon\Carbon;
class Test 
{
	
	public static function testham(){
		return 12;
	}
}

?>