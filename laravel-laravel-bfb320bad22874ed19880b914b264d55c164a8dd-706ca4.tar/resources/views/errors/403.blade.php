@extends('layouts.app')
 
@section('content')
	<h1>You don't have permission.</h1>
@endsection