@include('shared.alert')
<div class="form-group"> {!! Form::label('name', 'Name:') !!}
  {!! Form::text('name', null, ['class' => 'form-control']) !!} </div>
<div class="form-group"> {!! Form::label('email', 'E-mail:') !!}
  {!! Form::text('email', null, ['class' => 'form-control']) !!} </div>
<div class="form-group"> {!! Form::submit($submitButtonText, ['class' => 'btn btn-primary']) !!} </div>
