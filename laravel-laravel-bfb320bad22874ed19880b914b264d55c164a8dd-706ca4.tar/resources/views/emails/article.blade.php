<p>Dear friend,</p>
<p>
	Check this great article:
	{!! link_to_route('articles.show', $article['title'], $article['id']) !!}
</p>